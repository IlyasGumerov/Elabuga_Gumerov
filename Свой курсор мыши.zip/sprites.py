import os, sys

import pygame


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)

    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)

    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


size = width, height = 400, 400
screen = pygame.display.set_mode(size)
all_sprites = pygame.sprite.Group()
bomb_image = load_image("arrow.png")
bomb = pygame.sprite.Sprite(all_sprites)
bomb.image = bomb_image
bomb.rect = bomb.image.get_rect()
pygame.mouse.set_visible(False)
screen.fill(pygame.Color("black"))
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            if pygame.mouse.get_focused():
                x, y = pygame.mouse.get_pos()
                bomb.rect.x = x
                bomb.rect.y = y
            else:
                bomb.rect.x = -55
                bomb.rect.y = -55
    all_sprites.draw(screen)

    pygame.display.flip()
    screen.fill((0, 0, 0))
pygame.quit()
